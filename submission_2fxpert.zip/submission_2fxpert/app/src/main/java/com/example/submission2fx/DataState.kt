package com.example.submission2fx

enum class DataState {
    LOADING, SUCCESS, ERROR
}