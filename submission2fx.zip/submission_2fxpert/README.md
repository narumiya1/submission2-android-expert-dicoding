# submission2_expert

Continuous Integration : https://circleci.com/gh/narumiya1/submission_2fxpert.svg?style=shield
core/dinjct/CoreModule : certificate pinning, encryption
core/consumer-rules.pro
memory leak canary
